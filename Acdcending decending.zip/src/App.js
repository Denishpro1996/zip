import React from 'react'
import { useState } from 'react'
const App = () => {
    const [name,setName] = useState({
        name:"",
        lastname:""
    })
    const [error , setError] = useState({})
    const [isSubmit,setIsSubmit]= useState(false)
    const changeHandler = (e)=>{
        const {name,value} = e.target
        setName((oldvalue)=>{
            return{
                ...oldvalue,
                [name]:value
            }
        })
    }
    const submitHandler = (e)=>{
            e.preventDefault();
            setError(validate(name))
            setIsSubmit(true)
    }
    const validate = (value)=>{
        const error = {}
        if(!value.name){
            error.name = "name is required"
        }

        if(!value.lastname){
            error.lastname = "Lastname is required"
        }
    }
  return (
    <div>
      <form action="" onClick={submitHandler}>
        <input 
        type="text"
        placeholder='name'
        value={name.name}
        name="name"
        onChange={changeHandler}
         />
         <p>{error.name}</p>
        <input 
        type="text"
        placeholder='User lastname'
        value={name.lastname}
        name="lastname"
        onChange={changeHandler}
        />
        <p>{error.lastname}</p>
         <button type='submit'>Submit</button>
      </form>
    </div>
  )
}

export default App
