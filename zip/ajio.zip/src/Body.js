import React from 'react'
import './Body.css';

const Body = () => {
  return (
    <div className='add'>
      <h1> Come For A once and Stay Here LifeTime</h1>
      <img
        src='https://media.gq.com/photos/62b47970c206adc9cdaa422c/master/pass/menswear-art.jpg'
        alt=''
      />
    </div>
  );
}

export default Body;