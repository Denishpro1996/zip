import React from 'react';
import './SubmitButton.css';
const SubmitButton = () => {
  return (
    <div>
      <button className='btn'>Submit</button>
    </div>
  );
}

export default SubmitButton;