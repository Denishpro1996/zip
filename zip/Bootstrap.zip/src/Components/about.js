import React from "react";

const About = () => {
  return (
    <div className='alert alert-primary' role='alert'>
      <h1>Well-Come to About</h1>
    </div>
  );
};

export default About;
