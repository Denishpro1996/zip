import React from "react";

const Contact = () => {
  return (
    <div className='alert alert-primary' role='alert'>
      <h1>Well-Come Contact</h1>
    </div>
  );
};

export default Contact;
