import React from 'react'

const Home = () => {
  return (
    <div className='alert alert-primary' role='alert'>
      <h1>Well-Come to BootStrap With react</h1>
    </div>
  );
}

export default Home;