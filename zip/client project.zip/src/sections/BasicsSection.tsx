import {
  Alert,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import React from "react";
import { FieldErrors, UseFormRegister } from "react-hook-form";
import ENOTextField from "../components/ENOTextField"; //ENOTextField
import { ReceptionInvoice } from "../models/InvoiceReception";
import TextField from "@mui/material/TextField"; //TexField
import Box from "@mui/material/Box"; //Box
import TextareaAutosize from "@mui/material/TextareaAutosize"; //TextareaAutosize

export interface BasicsSectionProps {
  register: UseFormRegister<ReceptionInvoice>;
  errors: FieldErrors<ReceptionInvoice>;
}

export default function BasicsSection({
  register,
  errors,
}: BasicsSectionProps) {
  // ============================//
  const [value, setValue] = React.useState<Date | null>(new Date());
  const handleChange = (newValue: Date | null) => {
    setValue(newValue);
  };

  return (
    <>
      {/* ============Invoice Number ============*/}
      <div
        style={{
          width: "100vw",
          display: "flex",
          justifyContent: "space-around",
          marginTop: 15,
          marginLeft: 15,
        }}
      >
        {/* ------------------------Invoice Number------------------------ */}
        <Grid item xs={6} md={3}>
          <ENOTextField<ReceptionInvoice>
            label="Invoice Number"
            register={register}
            name={"invoiceNumber"}
            options={{
              required: "This field is required",
            }}
            error={errors.invoiceNumber}
            tooltipText="The unique identifier of the invoice"
          />
        </Grid>

        {/* ------------------------ Seller------------------------ */}

        <TextField id="outlined-search" placeholder="Seller" type="search" />

        {/* ------------------------ Name------------------------ */}

        <Grid item xs={12} md={4}>
          <FormControl fullWidth className="mb-3" style={{ width: "99%" }}>
            <InputLabel id="nameidlabel" variant="outlined"></InputLabel>
            <Select
              labelId="nameidlabel"
              {...register("buyerId", {
                required: true,
              })}
              defaultValue="-"
              name="nameid"
              id="nameid"
              variant="outlined"
            >
              <MenuItem value={"-"} disabled>
                Name (ID)
              </MenuItem>
              <MenuItem value={"10"}>Ten</MenuItem>
              <MenuItem value={"20"}>Twenty</MenuItem>
              <MenuItem value={"30"}>Thirty</MenuItem>
            </Select>
          </FormControl>
          {errors.buyerId && (
            <Alert severity="error">This Field Is Required.</Alert>
          )}
        </Grid>
        {/* ---------------------Date-------------------- */}
        <TextField
          id="date"
          label="Birthday"
          type="date"
          defaultValue="2017-05-24"
          sx={{ width: 220 }}
          InputLabelProps={{
            shrink: true,
          }}
        />
      </div>

      {/* ==============Payment Info================================ */}
      <div
        style={{
          width: "100vw",
          margin: "10px",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <h2>Payment Information</h2>
        {/* -------Box Container --------------*/}
        <div
          style={{
            display: "flex",
            width: "100%",
          }}
        >
          <div
            style={{
              height: "25vh",
              width: "50%",
            }}
          >
            <Box
              component="form"
              sx={{
                "& > :not(style)": { m: 1, width: "20ch" },
              }}
              noValidate
              autoComplete="off"
            >
              <TextField
                id="outlined-basic"
                label="Outlined"
                variant="outlined"
              />
              <TextField
                id="outlined-basic"
                label="Outlined"
                variant="outlined"
              />
              <TextField
                id="outlined-basic"
                label="Outlined"
                variant="outlined"
              />
            </Box>
            {/* ======Full Width =====*/}
            <Box
              className="fWidth"
              sx={{
                width: 580,
                maxWidth: "100%",
                margin: "7px",
              }}
            >
              <TextField fullWidth label="fullWidth" id="fullWidth" />
            </Box>
          </div>

          {/* =================Text Area =================*/}
          <div
            style={{
              height: "25vh",
              width: "50%",
            }}
          >
            <TextareaAutosize
              aria-label="empty textarea"
              placeholder="Comments"
              style={{ width: "99%", height: 128, resize: "none" }}
            />
          </div>
        </div>
      </div>
    </>
  );
}
